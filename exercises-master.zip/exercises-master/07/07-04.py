city1 = input()
city2 = input()
if city1[-1] == city2[0]:
    print("ВЕРНО")
else:
    print("НЕВЕРНО")
