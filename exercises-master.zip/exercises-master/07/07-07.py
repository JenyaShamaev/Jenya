message = input()
for i in range(len(message)):
    print(ord(message[i]), end=", ")
