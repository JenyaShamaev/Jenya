a = input()
while len(a) > 0:
    print(a)
    a = input()
    