word = input("Введите слово: ")
print("Слово " + word + " имеет длину " + str(len(word)))
