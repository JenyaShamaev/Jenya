first_city = input("Введите первый город: ")
second_city = input("Введите второй город: ")
if first_city != second_city:
    print("Да")
else:
    print("Нет")
