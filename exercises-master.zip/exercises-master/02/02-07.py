a = float(input("Введите число: "))
if abs(a) < 0.1 ** 6:
    print(10 ** 6)
else:
    print(1 / a)
