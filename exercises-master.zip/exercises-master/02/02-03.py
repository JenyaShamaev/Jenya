days = 2
profit = 3
length = 1400
print(length // (days * profit))
