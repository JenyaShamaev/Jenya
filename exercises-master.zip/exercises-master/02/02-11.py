number = float(input("Введите число: "))
if number > 0:
    print("+")
elif number == 0:
    print("0")
elif number < 0:
    print("-")
else:
    print("Ошибка")
    