string = input()
number = int(input())
for i in range(number):
    print(string, end="\n")
