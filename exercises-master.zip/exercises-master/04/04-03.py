number = int(input())
for i in range(number + 1):
    print("Куб числа ", i, " равен ", i ** 3)
