number = abs(int(input()))
answer = 1
for i in range(1, number + 1):
    answer = answer * i
print(answer)
