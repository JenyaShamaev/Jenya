answer = 1
for i in range(6):
    number = int(input())
    if number != 0:
        answer *= number

print(answer)
