number = int(input())
string = ""
for i in range(number):
    string += str(i) + " "
print(string)
