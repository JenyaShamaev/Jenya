word = "Ауууу!"
print("Человек: " + word + "\nЭхо: " + word)
