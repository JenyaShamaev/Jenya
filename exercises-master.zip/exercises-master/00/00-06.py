word1 = input()
word2 = input()
word3 = input()
print(word1 + "\n" + word2 + "\n" + word3)
