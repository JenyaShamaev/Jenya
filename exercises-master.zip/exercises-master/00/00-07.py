film_name = input()
cinema = input()
time = input()
print("Билет на " + film_name + " в " + cinema + " на " + time + " забронирован.")
