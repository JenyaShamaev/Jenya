word1 = input()
word2 = input()
word3 = input()
print(word3 + "\n" + word2 + "\n" + word1)
