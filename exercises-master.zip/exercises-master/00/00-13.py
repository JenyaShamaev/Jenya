#planet = "Меркурий"
