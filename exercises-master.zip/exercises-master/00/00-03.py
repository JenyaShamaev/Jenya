word = "Ауууу!"
print(word + "\n" + word)
