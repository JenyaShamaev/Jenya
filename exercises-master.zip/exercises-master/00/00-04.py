word = "Ауууу!\nАуууу!"
print(word)
