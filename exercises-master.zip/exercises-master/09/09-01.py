n = int(input())
bracket = list()
for i in range(n):
    word = input()
    bracket.append(word)
for elem in bracket:
    print(elem)
