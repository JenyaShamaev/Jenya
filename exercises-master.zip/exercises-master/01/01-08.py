if "кот" in input("Введите строку: ").lower():
    print("Мяу")
else:
    print("Гав")
