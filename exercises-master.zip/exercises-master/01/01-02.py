word = input("Введите слово: ")
if word == "Python":
    print("Да")
else:
    print("Нет")
